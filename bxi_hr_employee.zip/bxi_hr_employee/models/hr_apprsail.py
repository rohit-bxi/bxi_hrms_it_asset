from odoo import models, fields, api


class HrEmployeeAppraisal(models.Model):
    _name = 'hr.employee.appraisal'
    _description = 'Employee Appraisal'

    employee_id = fields.Many2one(
        'hr.employee',
        required=True
    )

    applicant_id = fields.Many2one(
        'hr.applicant',
        compute='_compute_applicant',
    )

    employee_code = fields.Char(
        related='employee_id.employee_code',
        readonly=True,
    )

    company_id = fields.Many2one(
        related='employee_id.company_id',
        readonly=True,
    )

    promotion_job_id = fields.Many2one(
        'hr.job',
        string="Promotion To Role"
    )

    release_date = fields.Date()

    effective_date = fields.Date()

    band = fields.Char(
        related='applicant_id.band',
        readonly=False,
    )

    basic_salary = fields.Float(
        related='applicant_id.basic_salary',
        readonly=False,
    )

    flexible_allowance = fields.Float(
        related='applicant_id.flexible_allowance',
        readonly=False,
    )

    @api.depends('employee_id')
    def _compute_applicant(self):
        for rec in self:
            applicant = self.env[
                'hr.applicant'
            ].search([
                ('employee_id', '=', rec.employee_id.id)
            ], limit=1)

            rec.applicant_id = applicant.id